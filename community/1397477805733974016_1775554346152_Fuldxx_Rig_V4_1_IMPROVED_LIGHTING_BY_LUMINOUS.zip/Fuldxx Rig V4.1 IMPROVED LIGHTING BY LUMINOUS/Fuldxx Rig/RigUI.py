import bpy

bl_info = {
    "name": "Fuldxx  Rig UI",
    "author": "Fuldxx",
    "version": (4,1),
    "blender": (4,2,0)
}

bpy.types.Object.selector = bpy.props.EnumProperty(
    items = [
        ('first', 'Main',''),
        ('second', 'Material','')
    ]
)
        
class RigUIPanel(bpy.types.Panel):
    bl_label = "GorillaRigUI"
    bl_idname = "OBJECT_PT_RigUI"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "FuldxxRigUI"
    
    @classmethod
    def poll (seld, context):
        try:
            return (bpy.context.active_object.get("rig_id") == 'f3wtgrsefg7h')
        except:
            return False
    
    def draw(self, context):
        layout = self.layout
        
        rig = context.active_object
        
        row = layout.box().row()
        row.label(text="Fuldxx Rig Properties")
        row.label(text="", icon = "PROPERTIES")
        
        Extras = rig.pose.bones["Extras"]
        
        selection = rig.selector
        layout.prop(rig, "selector", expand=True)
        
        if selection == "first":
            mat_obj = rig.children[0]
            r_eye = mat_obj.material_slots[0].material.node_tree.nodes["GorillaTagColorShader"].inputs
            
            box = layout.box()
            row = box.row()
            row.scale_x = 1
            row.alignment = 'CENTER'
            row.label(text="Rig", icon="BONE_DATA")
            box = layout.box()
            row = box.row()
            
            row.scale_x = 1
            row.alignment = 'CENTER'
            row.label(text="Face", icon="MESH_MONKEY")
            col = box.column(align = False)
            
            col.prop(Extras, '["Face Rig"]', toggle = True)
            col.prop(Extras, '["Face Tweak"]', toggle = True)
            col.prop(Extras, '["Head Track"]', toggle = True)
            col.prop(Extras, '["Eyelid Fix"]', toggle = True)
            col.prop(r_eye[37], "default_value", text = "Proced Mouth", toggle = True)
            box = layout.box()
            row = box.row()

            row.scale_x = 1
            row.alignment = 'CENTER'
            row.label(text="Collections", icon="ARMATURE_DATA")
            col = box.column(align = False)
            
            col.prop(Extras, '["Extra Fingers"]', toggle = True)
            col.prop(Extras, '["Pole Targets"]', toggle = True)
            col.prop(Extras, '["Arm Bones"]', toggle = True)
            col.prop(Extras, '["3D Nametag"]', toggle = True)
            box = layout.box()
            row = box.row(align=True)
            
            row.scale_x = 1
            row.alignment = 'CENTER'
            row.label(text="Snapping", icon="SNAP_GRID")
            col = box.column(align = True)
            
            col.prop(Extras, '["Snapping"]', toggle = True)
            col.prop(Extras, '["Snapping Res"]', slider = True)
        if selection == "second":
            mat_obj = rig.children[0]
            r_eye = mat_obj.material_slots[0].material.node_tree.nodes["GorillaTagColorShader"].inputs
            
            box = layout.box()
            row = box.row()
            row.scale_x = 1
            row.alignment = 'CENTER'
            row.label(text="Material", icon="SHADING_RENDERED")
            box = layout.box()
            row = box.row()
            row.scale_x = 1
            row.alignment = 'CENTER'
            row.label(text="Primary Color", icon="MATERIAL")
            col = box.column()
            col.enabled = not r_eye[3].default_value
            col.prop(r_eye[0], "default_value", text = "")
            
            col = box.column()
            
            col.prop(r_eye[3], "default_value", text = "GT Color Codes", toggle = True)
            
            row = box.row(align = True)
            row.enabled = r_eye[3].default_value
            row.prop(r_eye[4], "default_value", text = "R")
            row.prop(r_eye[5], "default_value", text = "G")
            row.prop(r_eye[6], "default_value", text = "B")
            
            col = box.column(align = True)
            
            col.prop(r_eye[1], "default_value", text = "Color Contrast")
            
            col.prop(r_eye[2], "default_value", text = "Color Multiplier")
            
            row = box.row()
            row.scale_x = 1
            row.alignment = 'CENTER'
            row.label(text="Extras", icon="LIGHTPROBE_VOLUME")
            col = box.column(align = True)
            
            col.prop(r_eye[7], "default_value", text = "Subsurface")
            col.prop(r_eye[8], "default_value", text = "Color Emission")
            
            row = box.row()
            row.scale_x = 1
            row.alignment = 'CENTER'
            row.label(text="Types", icon="RESTRICT_COLOR_ON")
            row = box.row(align = True)
            
            row.prop(r_eye[10], "default_value", text="Lava", toggle = True)
            row.prop(r_eye[9], "default_value", text="Distortion", toggle = True)
            row.prop(r_eye[11], "default_value", text="Ice", toggle = True)
            box.prop(r_eye[12], "default_value", text="Lava Emission")
            
            row = box.row()
            row.scale_x = 1
            row.alignment = 'CENTER'
            row.label(text="Fresnel", icon="MATFLUID")
            col = box.column(align = False)
            
            col.prop(r_eye[15], "default_value", text="")
            col.prop(r_eye[16], "default_value", text="Factor")
            col.prop(r_eye[17], "default_value", text="Contrast")
            col.prop(r_eye[18], "default_value", text="Opacity")
            
            box = layout.box()
            
            row = box.row()
            row.scale_x = 1
            row.alignment = 'CENTER'
            row.label(text="AO Settings", icon="OVERLAY")
            col = box.column(align = False)
            
            col.prop(r_eye[34], "default_value", text="Amount")
            col.prop(r_eye[33], "default_value", text="Distance")
            
            row = box.row()
            row.scale_x = 1
            row.alignment = 'CENTER'
            row.label(text="AO Glow", icon="LIGHT_DATA")
            col = box.column(align = True)
            
            col.prop(r_eye[35], "default_value", text="")
            col.prop(r_eye[36], "default_value", text="Glow Strength")
            
            
            box = layout.box()
            
            row = box.row()
            row.scale_x = 1
            row.alignment = 'CENTER'
            row.label(text="Eyes", icon="HIDE_OFF")
            
            row = box.row()

            col2 = row.column(align = True)
            col2.label(text="Right", icon = "TRIA_RIGHT")
            col2.prop(r_eye[25], "default_value", text="")
            col2.prop(r_eye[26], "default_value", text="")
            col2.prop(r_eye[27], "default_value", text="")
            
            col1 = row.column(align = True)
            label_row = col1.row()
            label_row.alignment = 'RIGHT'
            label_row.label(text="Left")
            label_row.label(text="", icon = "TRIA_LEFT")
            col1.prop(r_eye[28], "default_value", text="")
            col1.prop(r_eye[29], "default_value", text="")
            col1.prop(r_eye[30], "default_value", text="")
            col = box.column(align = True)
            col.prop(r_eye[31], "default_value", text="Blur")
            col.prop(r_eye[32], "default_value", text="Position")
            
            
            row = box.row()
            row.scale_x = 1
            row.alignment = 'CENTER'
            row.label(text="Glowy Eyes", icon="LIGHT_SUN")
            col = box.column()
            col.prop(r_eye[14], "default_value", text="Glowy Eyes", toggle = True)
            col.prop(r_eye[13], "default_value", text="")
            

def is_packed(img):
    try:
        return img.packed_files.values() != []
    except:
        return False


class ImgPack(bpy.types.Operator):
    bl_idname = "gorillatexture.imgpack"
    bl_label = ""
    
    id_name : bpy.props.StringProperty()
    
    def execute(self, context):
        img = bpy.data.images[self.id_name]
        if is_packed(img):
            if bpy.data.is_saved:
                img.unpack()
            else:
                img.unpack(method="USE_ORIGINAL")
        else:
            img.pack()
        return {"FINISHED"}
    
class ImgReload(bpy.types.Operator):
    bl_idname = "gorillatexture.imgreload"
    bl_label = ""
    
    id_name : bpy.props.StringProperty()
    
    def execute(self, context):
        bpy.data.images[self.id_name].reload()
        return {"FINISHED"}

def register():
    bpy.utils.register_class(RigUIPanel)
    bpy.utils.register_class(ImgPack)
    bpy.utils.register_class(ImgReload)
    
def  unregister():
    bpy.utils.unregister_class(ImgReload)
    bpy.utils.unregister_class(ImgPack)
    bpy.utils.unregister_class(RigUIPanel)
    #bpy.utils.unregister_class(RigUIPanel)
    
if __name__ == "__main__":
    register()
    
    # Credits for scripting
    
        # Tutorials:
    
          # BlueEvilGFX
          
        # Help:
    
          # ChatGPT